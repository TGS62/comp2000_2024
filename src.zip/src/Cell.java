import java.awt.Graphics;

public class Cell {
    private final int x;
    private final int y;
    private final int size;

    public Cell(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    public void paint(Graphics g) {
        g.drawRect(x, y, size, size);
    }
}
