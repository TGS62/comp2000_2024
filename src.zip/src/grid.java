public class grid { 
        private Cell[][] cells;
        private int rows;
        private int cols;

        public void Grid(int rows, int cols, int cellSize) {
            this.rows = rows;
            this.cols = cols;
            cells = new Cell[rows][col];
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    cells[i][j] = new Cell(i * cellSize + 10, j * cellSize + 10, cellSize);
                }
            }
        }

        public void paint(Graphics g) {
            for (int i = 0; i < cells.length; i++) {
                for (int j = 0; j < cell[i].length; j++) {
                    cells[i][j].paint(g);
            }
        }
    }
}
