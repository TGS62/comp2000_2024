/* 
public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello World");
    }
}
*/ 

/* Task 3 */ 
import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {  
    public static void main(String[] args) throws Exception {
        Main window = new Main(); 
        window.run();
    }

    public Main() {
        setTitle("Grid Drawing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new Canvas());
        pack();
        setLocationRelativeTo(null); 
    }

    public void run() {
        setVisible(true);
    }

    class Canvas extends JPanel {
        public Canvas() {
            setPreferredSize(new Dimension(720, 720));
        } 

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g); 
            for(int i = 10; i < 710; i += 35) {
                for(int j = 10; j < 710; j += 35) { 
                    g.drawRect(i, j, 35, 35);
                }   
            }   
        }          
    }
}

/* Task 4 */ 

